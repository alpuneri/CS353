<!DOCTYPE html>
<html>

<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
include("common.php");
include("head.html");

if (isset($_POST['finish_btn'])) {
	mysqli_query($con, "UPDATE order_ SET status='1' WHERE order_id='".$_GET['orderId']."'");
	header("Location: d_homePage.php");
}

function getOrder($orderId){
	include("dbConnection.php");
	$order_info = mysqli_fetch_array(mysqli_query($con, "SELECT o.order_id, c.name, c.surname, o.order_date, o.address, o.cost, o.status FROM customer c, order_ o WHERE o.order_id =".$orderId ." AND c.user_id = o.customer_id"));
			$menu_content = "";
			$select_menu_info = mysqli_query($con, "SELECT m.name, m.menu_id FROM contains_menu cm, order_ o, menu m WHERE cm.order_id = o.order_id AND cm.menu_id = m.menu_id AND o.order_id =".$orderId);
			
			while ($row_menu_info = mysqli_fetch_array($select_menu_info)) {
				$menu_content .= $row_menu_info['name']." -> ";
				$select_meal_info = mysqli_query($con, "SELECT me.name, me.meal_id FROM menu m, consists_of co, meal me WHERE m.menu_id = \"".$row_menu_info['menu_id']."\" AND m.menu_id = co.menu_id AND co.meal_id = me.meal_id");
				
				$meals = "";
				while ($row_meal_info = mysqli_fetch_array($select_meal_info)) {
					$meals .= $row_meal_info['name'];
					$select_ingredient_info = mysqli_query($con, "SELECT ingredient_name AS name FROM contains_ingredient WHERE order_id = \"".$orderId."\" AND meal_id = \"".$row_meal_info['meal_id']."\"");
					
					$ingredients = "";
					while ($row_ingredient_info = mysqli_fetch_array($select_ingredient_info)) {
						$ingredients .= $row_ingredient_info['name'] . ", ";
					}
					$ingredients = substr($ingredients, 0, -2);
					$meals .= " (".$ingredients.") - ";
				}
				$meals = substr($meals, 0, -2);
				$menu_content .= $meals . "<br>";
			}
	echo "<div class=\"list-row\">".
				 	"<div class=\"list-item\">".
				 		"<div class=\"list-item-row\" style='padding: 0.3vw;'>".
				 			"<div class=\"list-item-col\" style='width: 15%;'>Customer: </div>".
				 			"<div class=\"list-item-col\" style='width: 85%;'>".$order_info['name']." ".$order_info['surname']."</div>".
				 		"</div>".
					 	"<div class=\"list-item-row\" style='padding: 0.3vw;'>".
					 		"<div class=\"list-item-col\" style='width: 15%;'>Content: </div>".
					 		"<div class=\"list-item-col\" style='width: 85%;'>$menu_content</div>".
					 	"</div>".
					 	"<div class=\"list-item-row\" style='padding: 0.3vw;'>".
					 		"<div class=\"list-item-col\" style='width: 15%;'>Cost: </div>".
					 		"<div class=\"list-item-col\" style='width: 85%;'>".$order_info['cost']."</div>".
					 	"</div>".
					 	"<div class=\"list-item-row\" style='padding: 0.3vw;'>".
					 		"<div class=\"list-item-col\" style='width: 15%;'>Order Date: </div>".
					 		"<div class=\"list-item-col\" style='width: 85%;'>". date("j M Y - H:i", strtotime($order_info['order_date']))."</div>".
					 	"</div>".
					 	"<div class=\"list-item-row\" style='padding: 0.3vw;'>".
					 		"<div class=\"list-item-col\" style='width: 15%;'>Address: </div>".
					 		"<div class=\"list-item-col\" style='width: 85%;'>".$order_info['address']."</div>".
					 	"</div>".
				 	"</div>";
}

?>
<body style="background-color: #786ca4;">
	<div class="container" id="co">
		<?php
		include("d_dropdown.html");
		?>
		<div class="page" style="padding: 1vw; box-sizing: border-box;">
			<header>Order -
				<?php
				if (isset($_GET['orderId'])) {
					echo $_GET['orderId'];
				}
				?></header>
			<br>
			<div class="list" style="padding: 1vw; overflow: hidden; height: 90%; background-color: rgba(0,0,0,0.3);">
				<?php getOrder($_GET['order_id']); ?>
				<div class="list" style="box-sizing: border-box; padding: 2vw; height: 90%;">
					<form method="post">
						<button name="finish_btn" class="form-btn">
							Finish
						</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
</head>
</html>