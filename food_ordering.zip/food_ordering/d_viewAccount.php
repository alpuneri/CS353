<!DOCTYPE html>
<html>

<?php
include("common.php");
include("head.html");

if (isset($_POST['remove_btn'])) {
	$region_id = $_POST['region_id_in'];
	$update_delivery_guy = mysqli_query($con, "DELETE FROM works_in WHERE delivery_id='".$_SESSION['user_id']."' AND region_id='".$region_id."'");
}

if (isset($_POST['save_btn'])) {
	$update_user = mysqli_query($con, "UPDATE user SET username=\"".$_POST['username_in']."\", password=\"".$_POST['password_in']."\" WHERE user_id=\"".$_SESSION['user_id']."\"");
	$update_delivery_guy = mysqli_query($con, "UPDATE delivery_guy SET name=\"".$_POST['name_in']."\", surname=\"".$_POST['surname_in']."\", phone_number=\"".$_POST['phone_number_in']."\", mail=\"".$_POST['mail_in']."\" WHERE user_id=\"".$_SESSION['user_id']."\"");
	$insert_wi = mysqli_query($con, "INSERT INTO works_in VALUES ('".$_SESSION['user_id']."', '".$_POST['region_in']."')");
	
	if ($update_user == false || $update_delivery_guy == false || $insert_wi == false) {
		header("Location: d_viewAccount.php?update=false");
	}
	else {
		$_SESSION['name'] = $_POST['name_in'];
		$_SESSION['surname'] = $_POST['surname_in'];
		$_SESSION['username'] = $_POST['username_in'];
		$_SESSION['password'] = $_POST['password_in'];
		$_SESSION['mail'] = $_POST['mail_in'];
		$_SESSION['phone_number'] = $_POST['phone_number_in'];
		header("Location: d_viewAccount.php?update=true");
	}
}

$select_region = mysqli_query($con, "SELECT * from region");
$regions = "";
while ($row_region = mysqli_fetch_array($select_region)) {
	if (isset($_SESSION['region_id']) && $_SESSION['region_id'] == $row_region['region_id'])
		$regions .= "<option selected value=\"".$row_region['region_id']."\">".$row_region['name']."</option>";
	else
		$regions .= "<option value=\"".$row_region['region_id']."\">".$row_region['name']."</option>";
}

function getPersonalInfo($con) {
	global $regions;
	echo "<div class=\"list-item\" style=\"background-color: transparent;\">".
		 	"<div class=\"list-item-row\" style='align-items: center;'>".
				"<div class=\"list-item-col\"><label class=\"form-label\">Name: </label></div>".
				"<div class=\"list-item-col\"><input name=\"name_in\" class=\"form-input\" type=\"text\" value=\"".$_SESSION['name']."\"></div>".
			"</div>".
			"<div class=\"list-item-row\" style='align-items: center;'>".
				"<div class=\"list-item-col\"><label class=\"form-label\">Surname: </label></div>".
				"<div class=\"list-item-col\"><input name=\"surname_in\" class=\"form-input\" type=\"text\" value=\"".$_SESSION['surname']."\"></div>".
			"</div>".
			"<div class=\"list-item-row\" style='align-items: center;'>".
				"<div class=\"list-item-col\"><label class=\"form-label\">Username: </label></div>".
				"<div class=\"list-item-col\"><input name=\"username_in\" class=\"form-input\" type=\"text\" value=\"".$_SESSION['username']."\"></div>".
			"</div>".
			"<div class=\"list-item-row\" style='align-items: center;'>".
				"<div class=\"list-item-col\"><label class=\"form-label\">Password: </label></div>".
				"<div class=\"list-item-col\"><input name=\"password_in\" class=\"form-input\" type=\"text\" value=\"".$_SESSION['password']."\"></div>".
			"</div>".
			"<div class=\"list-item-row\" style='align-items: center;'>".
				"<div class=\"list-item-col\"><label class=\"form-label\">Mail: </label></div>".
				"<div class=\"list-item-col\"><input name=\"mail_in\" class=\"form-input\" type=\"text\" value=\"".$_SESSION['mail']."\"></div>".
			"</div>".
			"<div class=\"list-item-row\" style='align-items: center;'>".
				"<div class=\"list-item-col\"><label class=\"form-label\">Phone Number: </label></div>".
				"<div class=\"list-item-col\"><input name=\"phone_number_in\" class=\"form-input\" type=\"text\" value=\"".$_SESSION['phone_number']."\"></div>".
			"</div>".
			"<div class=\"list-item-row\" style='align-items: center;'>".
				"<div class=\"list-item-col\"><label class=\"form-label\">Add Region: </label></div>".
				"<div class=\"list-item-col\">".
					"<select name='region_in' class='form-input'>".
						$regions.
					"</select>".
				"</div>".
			"</div>".
		 "</div>";
}

function getRegions($con) {
	echo "<div class=\"list-item\" style=\"background-color: transparent;\">";

	$select_wi = mysqli_query($con, "SELECT * FROM works_in WHERE delivery_id='".$_SESSION['user_id']."'");
	while ($row_wi = mysqli_fetch_array($select_wi)) {
		$row_r = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM region WHERE region_id='".$row_wi['region_id']."'"));
		echo 	"<form method='post' style='width: 100%;'>".
					"<div class=\"list-item-row\" style='align-items: center;'>".
						"<div class=\"list-item-col\" style='width: 80%;'><input disabled name=\"region_name_in\" class=\"form-input\" type=\"text\" value=\"".$row_r['name']."\"></div>".
						"<input name=\"region_id_in\" class=\"form-input\" type=\"hidden\" value=\"".$row_r['region_id']."\">".
						"<button name='remove_btn' class='form-btn' style='width: 20%; margin-left: 1vw; font-size: 1.2vw;'>Remove</button>".
					"</div>".
				"</form>";
	}
	echo "</div>";
}

?>
<body style="background-color: #786ca4;">
	<div class="container">
		<?php include("d_dropdown.html"); ?>
		<div class="page" style="padding: 1vw; box-sizing: border-box;">
			<div class="col-6" style="align-self: center;">
				<form id="form" class="login-form" method="post" style="overflow: hidden; width: 100%; height: 95%;">
					<header>Personal Info</header>
					<br>
					<div class="list" style="min-height: 500px; background-color: rgba(0,0,0,0.3);">
						<?php getPersonalInfo($con); ?>
					</div>
					<button class="form-btn" name="save_btn" style="width: 20%;"><i class="material-icons" style="font-size: 1.7vw; transform: translateY(10%);">save</i> Save</button>
				</form>
				<?php
				if (isset($_GET['update'])) {
					if ($_GET['update'] == 'false')
						echo "<h3 style='color: white; margin-top: 0.5vw;'>Cannot update!</h3>";
					else
						echo "<h3 style='color: white; margin-top: 0.5vw;'>Update is successful!</h3>";
				}
				?>
			</div>
			<div class="col-6" style="align-self: center;">
				<form id="form" class="login-form" method="post" style="width: 100%; height: 90%;">
					<header>Regions</header>
					<br>
					<div class="list" style="min-height: 500px; background-color: rgba(0,0,0,0.3);">
						<?php getRegions($con); ?>
					</div>
				</form>
				<?php
				if (isset($_GET['update'])) {
					if ($_GET['update'] == 'false')
						echo "<h3 style='color: white; margin-top: 0.5vw;'>Cannot update!</h3>";
					else
						echo "<h3 style='color: white; margin-top: 0.5vw;'>Update is successful!</h3>";
				}
				?>
			</div>
		</div>
	</div>
</body>
</head>
</html>