/*function getUpdateInfoOwner(update) {
	var element = document.getElementById("form");
	if (update == 1)
		element.innerHTML += "<div class='list-item-row'><h4>Succesfully updated!</h4></div>"
	else if (update == -1)
		element.innerHTML += "<div class='list-item-row'><h4>Could not update!</h4></div>"
}*/

function menu_item_clicked() {
	//will direct the user to the edit page of the menu selected
}