<!DOCTYPE html>
<html>

<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
include("common.php");
include("head.html");

$select_delivers = mysqli_query($con, "SELECT * FROM delivers WHERE delivery_id='".$_SESSION['user_id']."' AND decision='1'");
if (mysqli_num_rows($select_delivers)) {
	while ($row_delivers = mysqli_fetch_array($select_delivers)) {
		$order = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM order_ WHERE order_id='".$row_delivers['order_id']."'"));
		if ($order['status'] != '1') {
			header("Location: d_finishPage.php?orderId=".$order['order_id']);
		}
	}
}

$messages = array();
$messageCount = 0;

if (isset($_POST['accept_btn'])) {
	mysqli_query($con, "UPDATE delivers SET decision='1' WHERE order_id='".$_POST['order_id_in']."' AND delivery_id='".$_SESSION['user_id']."'");
	mysqli_query($con, "UPDATE delivers SET decision='0' WHERE order_id='".$_POST['order_id_in']."' AND delivery_id!='".$_SESSION['user_id']."'");
}

if (isset($_POST['reject_btn'])) {
	mysqli_query($con, "UPDATE delivers SET decision='0' WHERE order_id='".$_POST['order_id_in']."' AND delivery_id='".$_SESSION['user_id']."'");
}

function getNewOrders() {
	include("dbConnection.php");
	$select_wi = mysqli_query($con, "SELECT * FROM works_in WHERE delivery_id='".$_SESSION['user_id']."'");
	if (mysqli_num_rows($select_wi) == 0) {
		echo "<h2>Currently, you did not choose a region!<h2>";
	}
	else {
		while ($row_wi = mysqli_fetch_array($select_wi)) {
			
			$select_orders = mysqli_query($con, "SELECT r.name as r_name, o.order_id as o_id, r.address as r_address, o.order_date as o_date, o.address as o_address, o.cost as o_cost FROM restaurant r, menu m, order_ o, contains_menu cm, delivers d WHERE r.restaurant_id=m.restaurant_id AND r.region_id='".$row_wi['region_id']."' AND m.menu_id=cm.menu_id AND cm.order_id=o.order_id AND d.order_id=o.order_id AND d.delivery_id='".$_SESSION['user_id']."' AND d.decision='2' AND o.status!='1'");
			
			if (mysqli_num_rows($select_orders) != 0) {
				while ($row_order = mysqli_fetch_array($select_orders)) {
					echo "<div class=\"list-item\" id=\"".$row_order['o_id']."\" style='display: flex; flex-direction: row; justify-content: flex-start;'>".
							"<div class=\"list-item-col\" style='width: 80%;'>".
								"<div class=\"list-item-row\">".
									"<div class=\"list-item-col\" style='font-size: 0.8vw;'>Restaurant: </div>".
									"<div class=\"list-item-col\" style='font-size: 0.8vw;'>".$row_order['r_name']."</div>".
								"</div>".
								"<div class=\"list-item-row\">".
									"<div class=\"list-item-col\" style='font-size: 0.8vw;'>Restaurant Address: </div>".
									"<div class=\"list-item-col\" style='font-size: 0.8vw;'>".$row_order['r_address']."</div>".
								"</div>".
								"<div class=\"list-item-row\">".
									"<div class=\"list-item-col\" style='font-size: 0.8vw;'>Delivery Address: </div>".
									"<div class=\"list-item-col\" style='font-size: 0.8vw;'>".$row_order['o_address']."</div>".
								"</div>".
								"<div class=\"list-item-row\">".
									"<div class=\"list-item-col\" style='font-size: 0.8vw;'>Cost: </div>".
									"<div class=\"list-item-col\" style='font-size: 0.8vw;'>".$row_order['o_cost']."</div>".
								"</div>".
						 	"</div>".
						 	"<div class=\"list-item-col\" style='width: 20%;'>".
						 		"<form method='post'>".
							 		"<div class=\"list-item-row\">".
							 			"<input value='".$row_order['o_id']."' name='order_id_in' type='hidden' class='form-btn'>".
							 			"<button class='form-btn' name='accept_btn'>Accept</button>".
							 		"</div>".
								 	"<div class=\"list-item-row\">".
								 		"<button class='form-btn' name='reject_btn'>Reject</button>".
								 	"</div>".
							 	"</form>".
							 "</div>".
						 "</div>";
				}
			}
		}
	}
}

?>
<body style="background-color: #786ca4;">
	<div class="container" id="co">
		<?php
		include("d_dropdown.html");
		?>
		<div class="page" style="padding: 1vw; box-sizing: border-box;">
			<div class="row" style="height: 2vw; justify-content: flex-start;">
				<button class="form-btn" onclick="window.location.href='d_homePage.php'" name="send_btn" style="width: 10%; height: 2vw; font-size: 1.5vw; margin-left: 1vw; ">Refresh</button>
				<h4 style="margin: 0px 0px 0px 2vw; color: white;">Page will be refreshed in</h4>
				<span id="timer" style="float: left; margin-left: 1vw; color: white;"></span>
			</div>
			<header>New Orders</header>
			<br>
			<div class="list" style="padding: 1vw; overflow: hidden; height: 90%; background-color: rgba(0,0,0,0.3);">
				<div class="list" style="box-sizing: border-box; padding: 2vw; height: 90%;">
						<?php getNewOrders(); ?>
				</div>
			</div>
		</div>
	</div>
</body>
<script type="text/javascript">
	document.getElementById('timer').innerHTML = 000 + ":" + 30;
	startTimer();

	function startTimer() {
  		var presentTime = document.getElementById('timer').innerHTML;
  		var timeArray = presentTime.split(/[:]+/);
  		var m = timeArray[0];
  		var s = checkSecond((timeArray[1] - 1));
  		
  		if(s == 59){
  			m = m - 1
  		}
  
  		document.getElementById('timer').innerHTML = m + ":" + s;
  		setTimeout(startTimer, 1000);
	}

	function checkSecond(sec) {
	  	if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
	  	if (sec < 0) {sec = "59"};
	  	return sec;
	}

	var x = setInterval(function() {
		window.location.href = "d_homePage.php";
	}, 30000);
</script>
</head>
</html>