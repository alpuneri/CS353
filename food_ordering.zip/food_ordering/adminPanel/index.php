<!DOCTYPE html>
<html>
<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

include_once("../dbConnection.php");

function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array();
    $alphaLength = strlen($alphabet) - 1;
    for ($i = 0; $i < 10; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

$signin = true;
if (isset($_POST['signin_btn'])) {
	$username = $_POST["username_in"];
	$password = $_POST["password_in"];
	
	$selectAdmin = mysqli_query( $con, "SELECT * from admin WHERE username=\"$username\" AND password=\"$password\"" );
	$rowAdmin = mysqli_fetch_array($selectAdmin);

	if ( mysqli_num_rows($selectAdmin) != 0 ) {
		session_start();
		$_SESSION['user_id'] = $rowAdmin['user_id'];
		$_SESSION['username'] = $rowAdmin['username'];
		$_SESSION['password'] = $rowAdmin['password'];
		header("Location: a_homePage.php");
	}
	else {
		$signin = false;
	}
}

$correctEmail = -5; //1 successful, 0 wrong email, -1 couldn't send
if (isset($_POST['send_mail_btn'])) {
	$new_pass = randomPassword();
	$select = mysqli_query( $con, "SELECT * FROM admin WHERE username=\"".$_POST['username_newPassword_in']."\"" );
	if (mysqli_num_rows($select) == 0) {
		$correctEmail = 0;
	}
	else {
		$update = mysqli_query( $con, "UPDATE admin SET password=\"$new_pass\" WHERE username=\"".$_POST['username_newPassword_in']."\"" );
		if (!$update) {
			$correctEmail = -1;
		}
		else {
			$correctEmail = 1;
		}
	}
}

function checkSignIn() {
	if (isset($_GET['signin']) && $_GET['signin'] == 'false')
		echo "<h4 style=\"color: #fbceb5; max-width: 350px; text-align: center; word-wrap: normal; padding: 0px 30px 10px 10px;\">You are signed out. You must sign in again to see the pages!</h4>";
}
?>
<head>
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script src="../js/foodOrdering.js"></script>
	<title>Food Delivery System</title>
</head>
<body style="background-color: #786ca4;">
	<div class="container">
		<div class="col-6">
			<img class="img-bg" src="../img/courier2.png">
		</div>
		<div class="col-6">
			<div class="form-div">
				<form class="login-form" method="post" name="login_form">
					<h2 style="margin: 5px; font-size: 30px; color: #fbceb5; text-align: center;">Food Delivery System ADMIN PANEL</h2>
					<h2 style="color: white; margin: 5px;">Sign In</h2>
					<div class="form-group">
						<input class="form-input" type="text" name="username_in" placeholder="Username" required="">
					</div>
					<div class="form-group">
						<input class="form-input" type="password" name="password_in" placeholder="Password" required="">
					</div>
					<?php
					checkSignIn();
					if (!$signin) {
					 	echo "<h4 style=\"color: #fbceb5; text-align: center;\">Invalid username and/or password!</h4>";
					}
					?>
					<div class="form-group">
						<button class="form-btn" name="signin_btn">Sign In</button>
					</div>
				</form>
				<div class="login-form">
					<h4 onclick="forgotPassword()" style="color: white; cursor: pointer;">Forgot Password</h4>
					<?php
					if ($correctEmail == 0) {
						echo "<h4 style=\"color: #fbceb5; text-align: center;\">Invalid email address!</h4>";
					}
					else if ($correctEmail == -1) {
						echo "<h4 style=\"color: #fbceb5; text-align: center;\">Password could NOT be sent!</h4>";
					}
					else if ($correctEmail == 1) {
						echo "<h4 style=\"color: #fbceb5; text-align: center;\">New password was successfully sent!</h4>";
					}
					?>
				</div>
				<form class="login-form" method="post" id="forgot_password_form" style="display: none;">
					<div class="form-group">
						<input class="form-input" type="text" name="username_newPassword_in" placeholder="Username" required="">
					</div>
					<div class="form-group">
						<button class="form-btn" name="send_mail_btn">Change Password</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		function forgotPassword() {
			var element = document.getElementById("forgot_password_form");
			if (element.style.display == 'none') {
				$("#forgot_password_form").show(1000);
			}
			else {
				$("#forgot_password_form").hide(1000);
			}
		}
	</script>
</body>
</html>